extends "res://Menus/Menu.gd"

func _on_Dynamic_level_level_done():
	visible = true

	yield(get_tree().create_timer(2.0), "timeout")

	get_tree().change_scene("res://Menus/MenuLevel.tscn")
