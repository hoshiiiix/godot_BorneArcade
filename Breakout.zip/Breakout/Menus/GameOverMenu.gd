extends "res://Menus/Menu.gd"

func _on_Ball_game_over():
	visible = true

	yield(get_tree().create_timer(2.0), "timeout")

	get_tree().change_scene("res://Menus/MenuLevel.tscn")
