extends Control

var  world="res://main.tscn"

func _ready():
	visible = false
	
func _on_restart_button_pressed():
	get_tree().change_scene(world)

