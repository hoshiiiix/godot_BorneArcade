extends Control

func start_game(rows, columns, difficulty):
	GameData.rows = rows
	GameData.columns = columns
	GameData.difficulty = difficulty
	
	GameData.lives = 3
	get_tree().change_scene("res://main.tscn")

func _on_Easy_pressed():
	start_game(3, 6, 1)

func _on_Medium_pressed():
	start_game(5, 8, 3)

func _on_Hard_pressed():
	start_game(7, 10, 5)
	
func _on_Quit_pressed():
	get_tree().quit()

