extends Node

var rows = 5
var columns = 8
var difficulty = 3
var lives = 3
