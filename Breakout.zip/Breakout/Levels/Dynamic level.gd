extends Node2D

export var rows= 3
export var cols = 10

export (int,1,5) var difficulty = 1

#const blue_brick_class  = preload("res://Bricks/BlueBrick.tscn")
#const green_brick_class  = preload("res://Bricks/GreenBrick.tscn")

const brick_class  = preload("res://Bricks/Brick.tscn")

const cell_width = 96
const cell_height = 32

var bricks = []

signal level_done


# Called when the node enters the scene tree for the first time.
func _ready():
	rows=GameData.rows
	cols=GameData.columns
	difficulty=GameData.difficulty
	 
	
	rows += difficulty
	var empty_brick_range = 0.6 - (difficulty/10.0)
	
	seed(3)
	
	for col in range(cols):
		for row in range(rows):
			var random = rand_range(0,1)
			if random < empty_brick_range:
				pass
			elif random < 0.7:
				var brick = brick_class.instance()
				init_brick(brick.Frames.BLUE,brick,row,col,false)
			elif random < 0.9:
				var brick = brick_class.instance()
				init_brick(brick.Frames.GREEN, brick,row,col,false)
			else:
				var brick = brick_class.instance()
				init_brick(brick.Frames.DARK, brick,row,col,true)
				
	
				
func init_brick(brick_frames_type ,brick,row,col,indestructible):
	brick.set_frames(brick_frames_type)
	brick.set_indestructible(indestructible)
	add_child(brick)
	brick.position.x = col*cell_width
	brick.position.y = row*cell_height
	if not indestructible:
		bricks.append(brick)





func _on_Ball_brick_hit(brick):
	var brick_position = bricks.find(brick)
	var brick_found = brick_position != -1 
	if not brick.is_alive_after_hit() and brick_found :
		bricks.remove(brick_position)
	
	if bricks.size() == 0:
		emit_signal("level_done")
		print("Level done")
		
	
