extends Node2D

onready var lives_label = $LivesLabel

func _process(delta):

	lives_label.text = "Lives: " + str(GameData.lives)
