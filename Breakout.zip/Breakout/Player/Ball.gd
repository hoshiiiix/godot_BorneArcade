extends KinematicBody2D

export var speed=500

onready var ball_visibility_notifier = get_node("VisibilityNotifier2D")


const player_container = preload("res://Player/Player_container.tres")
const audio_manager = preload("res://Audio/AudioManager.tres")

var world = "res://main.tscn"
var direction=Vector2(0.5,1)
var is_running= false  



signal brick_hit(brick)
signal game_over

func _ready():
	audio_manager.initialize()
	audio_manager.attach_sound(self,audio_manager.SoundType.HIT_BRICK)
	audio_manager.attach_sound(self,audio_manager.SoundType.HIT_WALL)
	audio_manager.attach_sound(self,audio_manager.SoundType.HIT_PLAYER)

func _physics_process(delta):
	
	if Input.is_action_just_pressed("fire"):
		is_running =  true
	elif not is_running:
		return
		
	check_if_game_over()
	
	direction=direction.normalized()
	var velocity=speed*direction*delta
	var collision =  move_and_collide(velocity)
	
	if collision != null:
		if collision.collider == player_container.player:
			direction = direction.bounce(collision.normal)
			direction.x = get_x_bounce_direction(collision)
			audio_manager.play_sound(audio_manager.SoundType.HIT_PLAYER,0.1)
			
		else:
			var hit_position = collision.position - collision.collider.global_position 
			var normal = fix_normal(collision.normal, hit_position)
			
			print (hit_position)
			print("normal", normal )
			direction = direction.bounce(normal)
			
			
			if collision.collider.get_meta("Brick"):
				var brick = collision.collider
				emit_signal("brick_hit", brick)
				brick.decrease_hit_points()
				if brick.is_indestructible():
					audio_manager.play_sound(audio_manager.SoundType.HIT_WALL,0.1)
				else:
					audio_manager.play_sound(audio_manager.SoundType.HIT_BRICK, 0.2)
			else:
				audio_manager.play_sound(audio_manager.SoundType.HIT_WALL,0.1)
			
		
		



func fix_normal(normal, hit_position):
	if normal.x == 1 or normal.x == -1 or normal.y == 1 or normal.y == -1:
		return normal 
		
		
	if hit_position.x < 2 and hit_position.y < 2:
		normal = Vector2(-0.5,-0.5)
		
		#upperright corner
	elif hit_position.x > 94 and hit_position.y < 2:
		normal = Vector2(0.5,-0.5)
		
		#lower right corner
	elif hit_position.x > 94 and hit_position.y > 30:
		normal = Vector2(0.5,0.5)
		
		#lower left corner
	elif hit_position.x <2 and hit_position.y > 30:
		normal = Vector2(-0.5,0.5)
	
	normal= normal.normalized()
	
	return normal



func get_x_bounce_direction(collision: KinematicCollision2D):
	var relative_x = collision.position.x - player_container.player.global_position.x
	var percentage= relative_x / player_container.player_width 
	return (percentage-0.5) * 2 #range of [-1,1]
	
	
	
func check_if_game_over():

	if not ball_visibility_notifier.is_on_screen():

		is_running = false

		GameData.lives -= 1

		if GameData.lives <= 0:

			GameData.lives = 0

			emit_signal("game_over")

			set_physics_process(false)

		else:

			reset_ball()
			
func reset_ball():

	is_running = false

	position = Vector2(448, 640)

	direction = Vector2(0.5, 1)
		
		
		
		
	


func _on_Dynamic_level_level_done():
	is_running = false
