extends KinematicBody2D
export var acceleration = 500  
export var player_length= 7

onready var player_map=get_node("Playermap")

const player_container = preload("res://Player/Player_container.tres")
const player_cell_width = 24 #pixel width of each individual player cell

var velocity=Vector2.ZERO
var friction=200

var is_running 


func _ready():
	build_player(player_length)
	player_container.player= self
	player_container.player_width= player_length*player_cell_width
	is_running = true
	
func build_player(player_length):
	assert(player_length >=2, "ERROR: You must use length of at least 2 cells")
	
	var left_part =0
	var middle_part=1
	var right_part=2
	
	var current_cell_x=0
	player_map.set_cell(current_cell_x,0,left_part)
	 
	for i in range(1,player_length-1):
		current_cell_x += 1
		player_map.set_cell(current_cell_x,0,middle_part)
	current_cell_x += 1
	player_map.set_cell(current_cell_x,0,right_part)
	
func _physics_process(delta):
	if not is_running:
		return
	
	fix_y_position()
	if Input.is_action_pressed("move_left"):
		velocity.x = -acceleration
	elif Input.is_action_pressed("move_right"):
		velocity.x = acceleration
		
	move_and_slide(velocity)
	
	velocity =velocity.move_toward(Vector2.ZERO,friction)
		
func fix_y_position():
	position. y=736
		


func _on_Dynamic_level_level_done():
	is_running= false


func _on_Ball_game_over():
	is_running= false
