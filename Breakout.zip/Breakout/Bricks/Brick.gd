extends StaticBody2D

onready var animated_sprite = get_node("AnimatedSprite")
enum Frames{BLUE = 0 , GREEN = 1 , DARK=2}
var hit_points

var blue_frames=preload("res://Bricks/Frames/blue_brick_frames.tres")
var green_frames=preload("res://Bricks/Frames/green_brick_frames.tres")
var dark_frames=preload("res://Bricks/Frames/dark_brick_frames.tres")
var current_frames = Frames.BLUE
var indestructible = false setget set_indestructible, is_indestructible

 


func set_frames(value):
	current_frames = value


func set_indestructible(value):
	indestructible = value
	
func is_indestructible():
	return indestructible


func change_frames():
	match current_frames:
		Frames.BLUE:
			animated_sprite.frames=blue_frames
		Frames.GREEN:
			animated_sprite.frames= green_frames
		Frames.DARK:
			animated_sprite.frames= dark_frames

# Called when the node enters the scene tree for the first time.
func _ready():  
	set_meta("Brick",true)
	
	change_frames()
	
	hit_points = animated_sprite.frames.get_frame_count("default")

func decrease_hit_points():
	if indestructible:
		return
	hit_points -= 1
	
	if animated_sprite.frame < animated_sprite.frames.get_frame_count("default") -1 :
		animated_sprite.frame += 1
	
	if hit_points <= 0:
		queue_free()
		
		
func is_alive_after_hit():
	return hit_points > 1
	
	

