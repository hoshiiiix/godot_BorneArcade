extends Resource
class_name AudioManager

enum SoundType{HIT_BRICK = 0 , HIT_WALL = 1 , HIT_PLAYER=2}

var hit_brick_audio 
var hit_wall_audio 
var hit_player_audio 

#contains audiomappings
# key: SoundType
#value: Array
# [0] AudioStreamPlayer
# [1] File path to the audio file 
var audio_dict = {}

func initialize():
	hit_brick_audio = AudioStreamPlayer.new()
	hit_wall_audio = AudioStreamPlayer.new()
	hit_player_audio = AudioStreamPlayer.new()
	
	audio_dict[SoundType.HIT_BRICK] = [hit_brick_audio,"res://GameAssets/Audio/hit_brick.wav"]
	audio_dict[SoundType.HIT_WALL] = [hit_wall_audio,"res://GameAssets/Audio/hit_wall.wav"]
	audio_dict[SoundType.HIT_PLAYER] = [hit_player_audio,"res://GameAssets/Audio/hit_player.wav"]

	
func attach_sound(node,type):
	if audio_dict[type] != null:
		var current_audio = audio_dict[type][0]
		var file_path = audio_dict[type][1]
		node.add_child(current_audio)
		var audio_file = load(file_path)
		current_audio.set_stream(audio_file)
	
	

func play_sound(type, offset):
	
	if audio_dict[type] != null:
		var current_audio = audio_dict[type][0]
		current_audio.play(offset)
		

	


