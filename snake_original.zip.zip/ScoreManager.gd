extends Node

var save_path = "/home/bornearcade/arcade/data/scores.json"
var scores = {}

func _ready():
	_ensure_file_exists()
	load_scores()

# 🔹 Vérifie que le dossier et le fichier existent
func _ensure_file_exists():
	var dir = Directory.new()
	if not dir.dir_exists("/home/bornearcade/arcade/data"):
		dir.make_dir_recursive("/home/bornearcade/arcade/data")
		
	var file = File.new()
	if not file.file_exists(save_path):
		file.open(save_path, File.WRITE)
		file.store_string("{}")
		file.close()

# 🔹 Charge le fichier JSON
func load_scores():
	var file = File.new()
	if file.file_exists(save_path):
		file.open(save_path, File.READ)
		var content = file.get_as_text()
		file.close()
		
		var result = JSON.parse(content)
		if result.error == OK and typeof(result.result) == TYPE_DICTIONARY:
			scores = result.result
		else:
			scores = {}

# 🔹 Sauvegarde dans le fichier
func save_scores():
	var file = File.new()
	file.open(save_path, File.WRITE)
	file.store_string(JSON.print(scores, "  "))
	file.close()

# 🔹 Ajoute un score et garde le Top 10
func save_score(game_name, player_name, score):
	load_scores()
	if not scores.has(game_name):
		scores[game_name] = []
	
	var game_scores = scores[game_name]
	game_scores.append({"name": player_name, "score": score})
	
	# Tri du plus grand au plus petit
	game_scores.sort_custom(self, "_sort_scores")
	
	# On ne garde que les 10 meilleurs
	if game_scores.size() > 10:
		game_scores = game_scores.slice(0, 9)
	
	scores[game_name] = game_scores
	save_scores()

func _sort_scores(a, b):
	return a["score"] > b["score"]

# 🔹 Récupère la liste pour l'affichage
func get_top_scores(game_name):
	load_scores()
	if scores.has(game_name):
		return scores[game_name]
	return []
