extends Node

export var snake_scene : PackedScene	

# Variables score
var score : int
var game_started : bool = false
var current_mode : String = "normal"

# food variables
var food_pos : Vector2
var regen_food : bool = true

# variables des cellules
var cells : int = 20
var cell_size : int = 50

# Snake variables
var old_data : Array
var snake_data : Array
var snake : Array

# Movement variables
var start_pos = Vector2(9,9)
var up = Vector2(0,-1)
var down = Vector2(0,1)
var left = Vector2(-1,0)
var right = Vector2(1,0)
var move_direction : Vector2
var can_move: bool

func _ready():
	# Connexion du signal de saisie de nom
	$NameEntry.connect("name_confirmed", self, "_on_NameEntry_confirmed")
	
	randomize()
	$Menu.show()
	$GameOverMenu.hide()
	$NameEntry.hide() # On s'assure qu'il est caché au début
	
	# On commence en pause pour le menu
	get_tree().paused = true
	new_game()
	
func new_game():
	# Nettoyage des anciens segments
	get_tree().call_group("segments", "queue_free")
	
	$GameOverMenu.hide() 
	$NameEntry.hide()
	
	# Initialisation du score et de l'affichage
	score = 0
	update_best_score()
	
	$Hud/ScoreLabel.text = "Score: " + str(score)
	move_direction = up
	can_move = true
	game_started = false
	
	generate_snake()
	move_food()
	
func generate_snake():
	old_data.clear()
	snake_data.clear()
	snake.clear()
	for i in range (3):
		add_segment(start_pos + Vector2(0,i)) 
		
func add_segment(pos):
	snake_data.append(pos)
	var SnakeSegment = snake_scene.instance()
	# On ajoute le segment au groupe pour pouvoir les supprimer facilement
	SnakeSegment.add_to_group("segments")
	SnakeSegment.rect_position = (pos * cell_size) + Vector2(0,cell_size)
	add_child(SnakeSegment)
	snake.append(SnakeSegment)
	
func _process(_delta):
	# On ne bouge que si le jeu n'est pas en pause
	if not get_tree().paused:
		move_snake()

func move_snake():
	if can_move:
		if Input.is_action_just_pressed("move_down") and move_direction != up:
			move_direction = down
			can_move = false
			if not game_started: start_game()
		if Input.is_action_just_pressed("move_up") and move_direction != down:
			move_direction = up
			can_move = false
			if not game_started: start_game()
		if Input.is_action_just_pressed("move_left") and move_direction != right:
			move_direction = left
			can_move = false
			if not game_started: start_game()
		if Input.is_action_just_pressed("move_right") and move_direction != left:
			move_direction = right
			can_move = false
			if not game_started: start_game()

func start_game(): 
	game_started = true 
	$MoveTimer.start()

func _on_MoveTimer_timeout():
	can_move = true
	old_data = [] + snake_data
	snake_data[0]+= move_direction
	
	for i in range(len(snake_data)):
		if i > 0:
			snake_data[i] = old_data[i -1]
		snake[i].rect_position = (snake_data[i] * cell_size) + Vector2(0, cell_size)
	
	check_out_of_bounds()
	check_self_eaten()
	check_food_eaten()

func check_out_of_bounds():
	if snake_data[0].x < 0 or snake_data[0].x > cells - 1 or snake_data[0].y < 0 or  snake_data[0].y > cells -1:
		end_game()

func check_self_eaten():
	for i in range(1,len(snake_data)):
		if snake_data[0] == snake_data[i]:
			end_game()
			

func end_game():
	$MoveTimer.stop() # Arrête le calcul du mouvement immédiatement
	get_tree().paused = true
	get_tree().call_group("segments", "hide")
	$NameEntry.show()

# FONCTION APPELÉE QUAND ON VALIDE LE NOM DANS NAMEENTRY
func _on_NameEntry_confirmed(nom_final):
	# 1. Sauvegarde
	ScoreManager.save_score("snake_" + current_mode, nom_final, score)
	# 2. Update visuel du record
	update_best_score()
	# 3. Cache la saisie et montre le menu de fin
	$NameEntry.hide()
	$GameOverMenu.show()

func move_food():
	while regen_food:
		regen_food = false
		food_pos = Vector2(randi()%cells, randi()%cells)
		for i in snake_data:
			if food_pos == i:
				regen_food = true
	$Food.position = (food_pos * cell_size) + Vector2(0,cell_size)
	regen_food = true
	
func check_food_eaten():
	if snake_data[0] == food_pos:
		score += 1
		$Hud/ScoreLabel.text = "Score: " + str(score)
		add_segment(old_data[-1])
		move_food()

func update_best_score():
	var top_scores = ScoreManager.get_top_scores("snake_" + current_mode)
	var record = 0
	if top_scores.size() > 0:
		record = top_scores[0]["score"]
	$Hud/BestScore.text = "Best Score : " + str(record)

func _on_GameOverMenu_restart():
	# On enlève la pause AVANT de relancer
	get_tree().paused = false
	new_game()

func _on_Menu_start_game(speed):
	$Menu.hide()
	get_tree().paused = false
	$MoveTimer.wait_time = speed
	
	if speed > 0.15:
		current_mode = "facile"
	elif speed > 0.08:
		current_mode = "normal"
	else:
		current_mode = "difficile"
	
	update_best_score() 
	game_started = false

func _on_GameOverMenu_back_menu():
	$GameOverMenu.hide()
	$Menu.show()
	new_game()
	get_tree().paused = true
