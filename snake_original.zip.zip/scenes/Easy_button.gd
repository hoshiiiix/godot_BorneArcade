extends Button

signal facile



func _on_Easy_button_pressed():
	emit_signal("facile") # Replace with function body.
