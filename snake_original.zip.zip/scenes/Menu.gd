extends CanvasLayer # Ou Control selon ton nœud racine

# On crée un seul signal qui envoie la vitesse choisie
signal start_game(speed)

func _on_Easy_button_pressed():
	emit_signal("start_game", 0.2) # Vitesse lente

func _on_Normal_Normal_pressed():
	emit_signal("start_game", 0.1) 



func _on_Difficult_button_pressed():
	emit_signal("start_game", 0.05) # Vitesse rapide


