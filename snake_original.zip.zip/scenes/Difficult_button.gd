extends Button

signal difficult



func _on_Difficult_button_pressed():
	emit_signal("difficult")
	
