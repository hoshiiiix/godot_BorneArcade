extends CanvasLayer

signal restart
signal back_menu

func _on_RestartButton_pressed():
	emit_signal("restart")


func _on_Back_Menu_Buttom_pressed():
	emit_signal("back_menu")
