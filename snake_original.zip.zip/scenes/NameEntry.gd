extends Control

signal name_confirmed(final_name)

var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ<" 
var current_index = 0
var player_name = ""
var on_accept_button = false 

onready var label_nom = $VBoxContainer/LabelTitle 
onready var grid = $VBoxContainer/GridContainer
onready var btn_accepter = $VBoxContainer/BtnAccepter 

func _ready():
	self.pause_mode = PAUSE_MODE_PROCESS
	btn_accepter.text = "ACCEPTER"
	btn_accepter.align = Label.ALIGN_CENTER
	_setup_grid()
	update_display()

func _setup_grid():
	grid.columns = 7 
	for child in grid.get_children():
		child.queue_free()
	
	for lettre in alphabet:
		var l = Label.new()
		l.text = lettre
		l.align = Label.ALIGN_CENTER
		l.valign = Label.VALIGN_CENTER
		l.rect_min_size = Vector2(45, 45)
		grid.add_child(l)

func _input(event):
	if not is_visible_in_tree():
		return

	if event.is_action_pressed("move_down"):
		on_accept_button = true
		update_display()
	elif event.is_action_pressed("move_up"):
		on_accept_button = false
		update_display()

	if not on_accept_button:
		if event.is_action_pressed("move_right"): 
			current_index = (current_index + 1) % alphabet.length()
			update_display()
		elif event.is_action_pressed("move_left"):
			current_index = (current_index - 1 + alphabet.length()) % alphabet.length()
			update_display()

	if event.is_action_pressed("ui_accept"):
		if on_accept_button:
			confirm_and_exit()
		else:
			var selection = alphabet[current_index]
			if selection == "<":
				if player_name.length() > 0:
					player_name = player_name.left(player_name.length() - 1)
			else:
				# --- LIMITE CHANGÉE À 11 CARACTÈRES ICI ---
				if player_name.length() < 11:
					player_name += selection
			
			label_nom.text = "NOM : " + player_name

func update_display():
	if not grid or not btn_accepter: return

	var style_focus = StyleBoxFlat.new()
	style_focus.bg_color = Color("e01e1e") # Rouge
	style_focus.set_corner_radius_all(3)
	
	var style_empty = StyleBoxEmpty.new()

	var i = 0
	for label in grid.get_children():
		if not on_accept_button and i == current_index:
			label.add_stylebox_override("normal", style_focus)
			label.add_color_override("font_color", Color.white)
		else:
			label.add_stylebox_override("normal", style_empty)
			label.add_color_override("font_color", Color.white)
		i += 1
	
	if on_accept_button:
		btn_accepter.add_stylebox_override("normal", style_focus)
		btn_accepter.add_color_override("font_color", Color.white)
	else:
		btn_accepter.add_stylebox_override("normal", style_empty)
		btn_accepter.add_color_override("font_color", Color.white)

func confirm_and_exit():
	var final = player_name
	if final == "": final = "JOUEUR"
	emit_signal("name_confirmed", final)
	
	player_name = "" 
	label_nom.text = "NOM : "
	on_accept_button = false
	
	get_tree().paused = false 
	hide()
