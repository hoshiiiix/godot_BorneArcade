extends Button

signal normal




func _on_Normal_Normal_pressed():
	emit_signal("normal")

